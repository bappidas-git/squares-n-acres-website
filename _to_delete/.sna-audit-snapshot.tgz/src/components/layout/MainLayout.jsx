import React from 'react';
import { useLocation } from 'react-router-dom';
import { m, AnimatePresence } from 'framer-motion';
import PATHS from '../../routes/paths';
import useBreakpoint from '../../hooks/useBreakpoint';
import Header from './Header';
import MobileHeader from './MobileHeader';
import Footer from './Footer';
import BottomNav from './BottomNav';
import ScrollToTop from '../common/ScrollToTop';
import { CustomBodyEnd } from '../seo/CustomHtml';
import WhatsAppButton from '../common/WhatsAppButton';
import BackToTop from '../common/BackToTop';
import styles from './MainLayout.module.css';

const pageVariants = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.3, ease: 'easeOut' } },
  exit: { opacity: 0, y: -12, transition: { duration: 0.2 } },
};

const MainLayout = ({ children }) => {
  // One breakpoint for JS and CSS: `md` = 900px (D51).
  const { isMobile } = useBreakpoint();
  const location = useLocation();

  return (
    <>
      {/* Scroll to top on route change */}
      <ScrollToTop />

      {/* Skip to main content — accessibility */}
      <a href="#main-content" className="skip-to-main">
        Skip to main content
      </a>

      {/* Header */}
      {isMobile ? <MobileHeader /> : <Header />}

      {/* Main Content */}
      {/* D52: the header is transparent over the home hero, so the home page
          starts at the top of the viewport rather than below the bar. */}
      {/* `tabIndex={-1}` is what makes the skip link work: without it the
          browser moves the scroll position to `#main-content` and leaves focus
          in the header, so the next Tab goes back to the navigation the
          visitor just skipped. It is not a tab stop — only a focus target. */}
      <main
        id="main-content"
        tabIndex={-1}
        className={[styles.main, location.pathname === PATHS.home ? styles.flush : '']
          .filter(Boolean)
          .join(' ')}
      >
        <AnimatePresence mode="wait">
          <m.div
            key={location.pathname}
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            {children}
          </m.div>
        </AnimatePresence>
      </main>

      {/* Footer — it renders the newsletter band when settings enable it */}
      <Footer />

      {/* Back to Top button */}
      <BackToTop />

      {/* One tap to a conversation, on every public page. It renders nothing
          when no WhatsApp number is configured (§14) and never appears in the
          admin panel, which has its own layout. */}
      <WhatsAppButton variant="float" context="floating" />

      {/* Mobile Bottom Nav */}
      {isMobile && <BottomNav />}

      {/* `seoSettings.customBodyEndHtml`, appended to the body once per visit.
          Its head counterpart is rendered by `<Seo>`; both are administrator
          territory and both are documented as a trust boundary in
          `components/seo/CustomHtml.jsx` (§6.14). */}
      <CustomBodyEnd />
    </>
  );
};

export default MainLayout;
