import { useState } from 'react';
import { Icon } from '@iconify/react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { Link } from 'react-router-dom';

import IconButton from '../ui/IconButton';

import styles from './RowActions.module.css';
import { TABLES } from '../../config/adminCopy';

/** What an `href` action adds: a new tab, without handing it this one. */
const EXTERNAL = { target: '_blank', rel: 'noopener noreferrer' };

/** The schemes the device answers itself — the dialler, the mail app, SMS. */
const DEVICE_SCHEMES = /^(tel|mailto|sms):/i;

/**
 * The attributes an `href` action's link carries.
 *
 * A web address opens in a new tab — a full one, and a path on this site such
 * as "View on the site"'s `/about`, which is a web address all the same: when
 * only `https:` counted, every "View on the site" took the admin's own tab to
 * the public page (QA-56). A `tel:` or `mailto:` one is handed to the dialler
 * or the mail app from this tab: given a new tab of its own, it left an empty
 * one behind on a desktop browser every time "Call" was chosen (QA-53).
 */
const linkProps = (href) => (href && !DEVICE_SCHEMES.test(href) ? EXTERNAL : null);

/**
 * Keeps a click inside the menu from reaching the row it belongs to.
 *
 * The menu is portalled out of the table in the DOM but not in React, and
 * React bubbles a synthetic event through the component tree: a click on the
 * backdrop — how a menu opened by mistake is closed — reached `DataTable`'s
 * row, and the row opened its record (QA-56).
 */
const stopAtMenu = (event) => event.stopPropagation();

/**
 * The per-row controls of `DataTable`.
 *
 * Wide enough (≥ 900 px) and they are icon buttons; below that they collapse
 * into a kebab menu, because five 44 px targets do not fit on a phone card.
 * Either way every control has a name — `IconButton` requires one and the menu
 * spells it out (§8.3).
 *
 * An action is a button, a router link (`to`) or an external one (`href`,
 * opened in a new tab — "View on site" is a different context, not a
 * navigation away from the record being edited — unless it is a `tel:` or a
 * `mailto:`, which the device answers without a tab).
 *
 * @param {object} props
 * @param {Array<{key: string, label: string, icon?: string, onClick?: () => void,
 *   to?: string, href?: string, danger?: boolean, disabled?: boolean}>} props.actions
 * @param {boolean} [props.compact] render the kebab menu
 * @param {string} [props.menuLabel]
 */
export default function RowActions({
  actions = [],
  compact = false,
  menuLabel = TABLES.rowActions,
}) {
  const [anchor, setAnchor] = useState(null);

  if (actions.length === 0) return null;

  if (!compact) {
    return (
      <span className={styles.inline}>
        {actions.map((action) => (
          <IconButton
            key={action.key}
            label={action.label}
            size="sm"
            to={action.disabled ? undefined : action.to}
            href={action.disabled ? undefined : action.href}
            {...linkProps(action.href)}
            disabled={action.disabled || undefined}
            className={action.danger ? styles.danger : undefined}
            onClick={(event) => {
              event.stopPropagation();
              action.onClick?.(event);
            }}
          >
            <Icon icon={action.icon || 'mdi:dots-horizontal'} width="18" height="18" />
          </IconButton>
        ))}
      </span>
    );
  }

  const close = () => setAnchor(null);

  return (
    <>
      <IconButton
        label={menuLabel}
        size="sm"
        aria-haspopup="menu"
        aria-expanded={anchor ? true : undefined}
        onClick={(event) => {
          event.stopPropagation();
          setAnchor(event.currentTarget);
        }}
      >
        <Icon icon="mdi:dots-vertical" width="20" height="20" />
      </IconButton>
      <Menu
        anchorEl={anchor}
        open={Boolean(anchor)}
        onClose={close}
        onClick={stopAtMenu}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        {actions.map((action) => (
          <MenuItem
            key={action.key}
            disableRipple
            disabled={action.disabled}
            component={action.to ? Link : action.href ? 'a' : 'li'}
            to={action.to}
            href={action.href}
            {...linkProps(action.href)}
            className={action.danger ? styles.dangerItem : undefined}
            onClick={(event) => {
              event.stopPropagation();
              close();
              action.onClick?.(event);
            }}
          >
            <Icon
              icon={action.icon || 'mdi:chevron-right'}
              width="18"
              height="18"
              className={styles.menuIcon}
            />
            {action.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
}
