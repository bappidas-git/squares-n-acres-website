# Backend notes — SEO, sitemaps and robots

Merged into `backend_developer_guidelines/06_SEO_SITEMAP_ROBOTS.md`. The SEO
engine itself — scoring, templates, the JSON-LD graph — runs in the browser and
is documented in `docs/SEO_ENGINE.md`. What the API owns is the nine documents
below and the redirect list, and every one of them is search-engine-facing: a
broken sitemap costs traffic silently.

Edit this file, never the generated one.

## Sitemaps

Six documents, served with `Content-Type: text/xml` and **no envelope**, under
the API base **and** mirrored at the site root for the web server to proxy
(§5.13):

| Path                      | Contents                                                                                               |
| ------------------------- | ------------------------------------------------------------------------------------------------------ |
| `/sitemap.xml`            | the index — one `<sitemap>` per document below, each with the newest `<lastmod>` of the rows it covers |
| `/sitemap-properties.xml` | active properties, with `<image:image>` per gallery picture                                            |
| `/sitemap-localities.xml` | active localities                                                                                      |
| `/sitemap-developers.xml` | active developers                                                                                      |
| `/sitemap-articles.xml`   | published articles whose `published_at` has arrived                                                    |
| `/sitemap-pages.xml`      | published CMS pages, plus the static routes                                                            |

The index:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://www.squaresnacres.com/sitemap-properties.xml</loc>
    <lastmod>2026-09-15T07:20:00.000Z</lastmod>
  </sitemap>
</sitemapindex>
```

A property entry, which is the only one with images:

```xml
<url>
  <loc>https://www.squaresnacres.com/properties/lakeview-heights-3-bhk-whitefield</loc>
  <lastmod>2026-06-29T06:20:00.000Z</lastmod>
  <changefreq>weekly</changefreq>
  <priority>0.8</priority>
  <image:image>
    <image:loc>https://res.cloudinary.com/.../lakeview-1.jpg</image:loc>
    <image:title>Lakeview Heights – 3 BHK Apartment in Whitefield – exterior</image:title>
  </image:image>
</url>
```

Rules:

- The `image` namespace is declared on `<urlset>`:
  `xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"`. Declare it on
  the properties document only.
- `<image:title>` is the picture's `alt`. Never emit an image without one.
- `changefreq` and `priority` come from `seoSettings.sitemap`, per entity type,
  and a record's own `seo.sitemap` overrides both.
- A record with `seo.robots.index === false`, or whose URL matches
  `seoSettings.sitemap.excludeUrls`, is left out. A page that tells robots not to
  index it has no business in a sitemap.
- The `includeProperties` / `includeLocalities` / `includeDevelopers` /
  `includeArticles` / `includePages` switches drop a whole document; the index
  then omits it too.
- URLs are absolute and built from `seoSettings.siteUrl`, **never** from the
  request's `Host`. A sitemap fetched through a staging hostname must still name
  the canonical one.
- Split at **50,000 URLs** or 50 MB per document. The index already exists, so
  splitting is `-properties-2.xml` and one more `<sitemap>` entry.

## Lastmod and caching

`<lastmod>` is the record's own `updated_at`, in ISO-8601 UTC. Two refinements:

- A property's `lastmod` should move when one of its **children** moves —
  an image swapped or a floor plan added is a change to the page. Touch the
  parent's `updated_at` in the child's model events, or take
  `GREATEST(properties.updated_at, MAX(property_images.updated_at))`.
- The index's per-document `lastmod` is the **maximum** `lastmod` of the rows
  that document contains, so a crawler can skip a document that has not changed.

Generation is the most expensive read in the system — every active property with
its images — so cache each document for **one hour**:

```php
return Cache::remember("sitemap:{$name}", now()->addHour(), fn () => $this->build($name));
```

Bust the whole `sitemap:*` group when a property, locality, developer, article or
page is created, updated or deleted, so an editor who publishes a listing does
not wait out the hour. `Cache-Control: public, max-age=3600` on the response, to
match.

## robots.txt

Served from `seoSettings.robotsTxt`, verbatim, with two substitutions at serve
time: `%siteurl%` becomes `seoSettings.siteUrl`, and the per-type `Sitemap:`
lines are appended after the index's.

The shipped default allows everything except the admin, the shortlist and the two
query shapes that create infinite crawl space, then names the twenty agents that
matter — the search engines and the AI crawlers — explicitly, and ends with the
six `Sitemap:` lines. It is reproduced in full in the generated document.

Two rules for the API:

- The admin UI can edit this text, so **never validate it into uselessness**, but
  do refuse a body that removes every `Sitemap:` line — the SEO settings screen
  offers "Restore recommended" for exactly that.
- `Content-Type: text/plain; charset=utf-8`. A robots file served as HTML is
  ignored.

On a **staging** host the file must be the four-line blanket disallow instead.
That is a deployment concern, not a data one: see `07_DEPLOYMENT.md`.

## RSS

`/rss.xml` is the latest **20** published articles, newest first:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Squares N Acres — Insights</title>
    <link>https://www.squaresnacres.com/insights/articles</link>
    <description>…</description>
    <language>en-IN</language>
    <lastBuildDate>Thu, 15 Jan 2026 09:30:00 GMT</lastBuildDate>
    <atom:link href="https://www.squaresnacres.com/rss.xml" rel="self" type="application/rss+xml" />
    <item>
      <title>Buying a Plot in Bengaluru: BDA, BMRDA and BIAAPA Approvals Explained</title>
      <link>https://www.squaresnacres.com/insights/articles/plot-buying-checklist-bda-bmrda-biaapa</link>
      <guid isPermaLink="true">https://www.squaresnacres.com/insights/articles/plot-buying-checklist-bda-bmrda-biaapa</guid>
      <pubDate>Sun, 23 Aug 2026 06:30:00 GMT</pubDate>
      <description>A site is only as good as the approval behind it. …</description>
      <category>Buying Guides</category>
      <author>Legal Desk</author>
    </item>
  </channel>
</rss>
```

`pubDate` and `lastBuildDate` are **RFC-822**, not ISO-8601 — the one place in
the whole contract where a date is not ISO. `description` is the article's
`excerpt` as plain text, never its HTML.

## llms.txt

`/llms.txt` is Markdown, per the llms.txt convention, served as
`text/plain; charset=utf-8`: an H1, a one-paragraph summary of the company, then
`## Localities`, `## Property types`, `## Featured properties` (top 10),
`## Guides` (top 10 articles) and `## Contact`. Every link is absolute.

It is stored in `seoSettings.llmsTxt` and regenerated from live data on demand —
`GET /admin/seo/llms-preview` renders the current data without saving, which is
what the SEO settings screen shows before an editor commits it.

## Redirects

Three layers, and each one exists because the one below it cannot cover
everything:

1. **Nginx**, for the redirects that never change — the canonical host, HTTP to
   HTTPS, and any bulk migration of old URLs. Fastest, and it works before a byte
   of JavaScript runs. The SEO dashboard exports an `redirects.nginx.conf`
   snippet for exactly this.
2. **Laravel**, on the API's own 404 path and for anything server-rendered:
   look up `from_path`, answer a real **301** or **302**, and increment `hits`.
   `GET /redirects/resolve?path=` is that lookup as an endpoint.
3. **The SPA**, which loads `GET /redirects` once (cached ten minutes in memory
   and in `sessionStorage`) and performs a client-side `<Navigate replace>` on an
   exact path match, preserving the query string.

Layer 3 is a safety net, not the answer: a client-side redirect returns 200 to
the crawler that asked for the old URL and passes no link equity. Every redirect
that matters for SEO belongs in layer 1 or 2. Layer 3 exists so an editor can add
one at 4 p.m. without a deployment.

Comparison is on the path only, query preserved, trailing slash normalised away,
and case-insensitive. One hop only.

## Canonical host

Exactly one hostname serves the site, and everything else redirects to it with a
**301**:

- `http://…` → `https://…`
- `squaresnacres.com` → `www.squaresnacres.com`
- any other hostname pointing at the server → the canonical one

The canonical URL the pages emit comes from `seoSettings.siteUrl`, so the two can
disagree if someone edits one and not the other. They must not: the go-live
checklist verifies `seoSettings.siteUrl` matches the host Nginx canonicalises to,
and the sitemaps, RSS, llms.txt and every `<link rel="canonical">` all read that
one value.

## Escaping

Every XML document the API produces is assembled from database text, and that
text contains ampersands.

- Escape `&`, `<`, `>`, `"` and `'` in every element and attribute value —
  including inside `<image:title>` and `<description>`. `Villas & Plots` in a
  title breaks the whole document otherwise, and a crawler reports the sitemap as
  invalid rather than skipping one entry.
- A URL goes through the same escaping: a `?` is fine, an `&` between query
  parameters is `&amp;`.
- Strip control characters. XML 1.0 forbids most of them and a stray one from a
  pasted description makes the file unparseable.
- Do not double-escape. If the source is HTML (`description` on a property),
  convert it to plain text first, then escape once.
- Emit the declaration `<?xml version="1.0" encoding="UTF-8"?>` as the very first
  bytes: no BOM, no leading newline, no whitespace. A single space in front of it
  is a parse error.
