# Backend notes — testing and parity

Merged into `backend_developer_guidelines/08_TESTING_AND_PARITY.md`. The claim
this whole package makes is that the frontend cannot tell the two backends
apart. This file is how you prove it.

Edit this file, never the generated one.

## Running both

Run the mock beside the Laravel API on one machine and you can compare them
request by request.

```bash
# terminal 1 — the reference implementation, on port 4000
cd squares-n-acres-website
npm install
npm run mock                       # http://localhost:4000/api

# terminal 2 — the implementation under test
cd squares-n-acres-api
php artisan serve --port=8000      # http://localhost:8000/api

# terminal 3 — the site, pointed at either one
cd squares-n-acres-website
REACT_APP_API_URL=http://localhost:8000/api npm start
```

Four things make the mock a fair reference:

- **It is seeded from the same data.** `db.json` in this package is the byte
  copy of the seed; import it with `seed-mapping.md` and both servers answer
  about the same 36 properties, 20 localities and 45 leads.
- **`npm run mock:reset` restores it.** The mock writes to
  `mock-server/.runtime/db.json`, never to the seed, so a comparison run that
  creates records is undone by one command.
- **`MOCK_DELAY_MS=400 npm run mock` adds latency**, which is how you find the
  loading states that only look right at localhost speed.
- **`MOCK_TOKEN_TTL_HOURS=0.02` expires a token in about a minute**, which is how
  you test the auto-logout without waiting a day.

The mock is not a specification of performance, of concurrency or of SQL. It is a
specification of **shape**: status codes, envelopes, field names, ordering and
the business rules of `05_BUSINESS_RULES.md`.

## Comparing responses

`scripts/smoke-api.js` walks the endpoint registry — the same file the frontend
calls through — and asserts status codes, envelopes, pagination meta, RBAC and
two dozen behaviours a status code cannot describe.

**Against one server:**

```bash
npm run smoke -- --baseUrl=https://api.squaresnacres.com/api
npm run smoke -- --baseUrl=https://api.squaresnacres.com/api --verbose
npm run smoke -- --baseUrl=… --email=someone@squaresnacres.com --password=…
```

It prints a `key | method | path | expected | actual | ok` table, a pass/fail
count, and exits non-zero on any failure — so it drops straight into CI.

**Against two servers at once:**

```bash
npm run smoke -- --baseUrl=http://localhost:8000/api --compare=http://localhost:4000/api
```

Compare mode sends **the same read to both** and prints only what differs:

| What it compares                                                                                             | Why                                                                            |
| ------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| the HTTP status                                                                                              | a 404 where the mock answers 200 is a missing route or a wrong scope           |
| the envelope keys (`data`, `meta`, `message`)                                                                | `{ "data": … }` versus a bare array is the single most common mistake          |
| `meta`'s key set and the types of `page`, `perPage`, `total`, `totalPages` — and whether `facets` is present | a list that forgets `meta` breaks every paginator on the site                  |
| the key set of `data` — of the first item, for a list                                                        | a missing `slug`, a `snake_case` leak, a read-only embed that was not embedded |
| the content type, for the CSV, XML and text endpoints                                                        | a sitemap served as `text/html` is ignored by crawlers                         |

It deliberately does **not** compare values. The two servers hold different rows,
`updatedAt` differs by definition, and a diff full of legitimate differences hides
the one that matters. Values are what the Postman tests and the module checklist
below are for.

Compare mode is **read-only**: it signs in on both servers and then sends only
`GET` requests, so it is safe against production. Writes are covered by running
the full smoke walk against each server in turn — do that against staging, never
against production, because it creates and deletes records.

Read the table top to bottom and fix in this order: status differences first
(something is missing), then envelope differences (something is shaped wrong),
then `data` key differences (something is named wrong). A status difference
usually explains the two below it.

## Postman

`postman_collection.json` and `postman_environment.json` are generated from the
same registry, with the captured mock response saved under each request as an
example.

1. Import both files (Postman → Import → drop both).
2. Select the **Squares N Acres — Local mock** environment.
3. Open `auth › auth › POST /auth/login` and send it. Its test script writes
   `{{token}}` into the environment; every other request inherits it from the
   collection's bearer auth.
4. **Run the collection** (Collection → Run). Every request asserts its status
   and its envelope.
5. To test the Laravel API, disable the local `baseUrl` row in the environment,
   enable the production one, sign in again and run it again. Every test that
   passed against the mock must pass.

To work as another role, change `email` and `password` in the environment — the
manager and sales values are there, disabled — and sign in again. That is the
fastest way to check the 403s of `02_AUTH_AND_RBAC.md`: a sales token on
`DELETE /admin/leads/:id` must be 403, not 200 and not 404.

The saved responses are captured from the mock and their timestamps are
normalised to a fixed instant, so they show the **shape**, not live data. Use
them to see what a field is called and how it nests, not to assert a value.

## Acceptance checklist

Per module, and each line is a thing a person clicks or a command someone runs.
Work through it with the site pointed at the API under test.

**Auth and roles** — sign in as each of the three roles; a wrong password is 401
"Invalid email or password."; the token expires and the site signs itself out
with a toast; `GET /auth/profile` matches the login response; sign in as the same
account in a second browser and the first stays signed in (QA-65); changing the
password revokes the other sessions; a sales token on an admin-only route is
**403**, and a manager on `PUT /admin/settings` is **403**.

**Properties** — the public list paginates and its `meta.facets` counts match the
filter rail; `bedrooms=3` returns only 3-BHK listings, and `bedrooms=5` returns
five-and-above; a price filter drops `priceOnRequest` listings; `sort=price-asc`
puts them last; an inactive listing is 404 by slug; `POST …/view` moves the
counter once an hour and not twice; `similar` returns the editor's picks first;
create, edit, publish and duplicate a listing from the admin and find the copy
inactive with a `-copy` slug; two listings titled in Devanagari alone are given
`property-<id>` each, never `''`, and a replace keeps it (QA-60). A `PATCH
{ "isActive": true }` on a draft with no image, a 120-character description, no
summary and no price is 422 with `images`, `description`, `shortDescription` and
`pricing.price` in `errors` and the four gaps in `data.notReady[0].gaps`, while
`PATCH { "isFeatured": true }` on a live listing is 200 without being asked; a bulk
`activate` of one ready and one unready draft is 422 and activates neither; a `PUT`
carrying an `updatedAt` other than the stored one is 409 with `data.conflict:
'stale'` and writes nothing, and the same `PUT` without `updatedAt` is 200;
`GET /properties/featured?listingType=rent` answers only featured rentals; and a
listing featured and published from the admin is in the home page's Featured row
with ten others featured before it (QA-62).

**Leads** — submit every public form and check the source lands as the documented
value; a legacy source value is mapped, not rejected; the honeypot answers 200 and
stores nothing; the eleventh submission in a minute is 429; `enquiryCount` moved;
a status change appends exactly one activity and a no-op change appends none; a
sales user sees only their own and unassigned leads, in the list, the detail, the
export **and** the dashboard; claiming an assigned lead is 409; the CSV opens in
Excel with the accents intact.

**Articles** — a draft is 404 in public and 200 with a preview token; an article
scheduled for five minutes' time is invisible, and visible five minutes later
without anybody deploying; the RSS feed holds the latest 20; the taxonomy pages
filter correctly. Publishing a draft with no excerpt, no featured image or fewer
than 300 words is 422 by `PUT`, `PATCH` and the bulk action, and the bulk refusal
names each article and leaves all of them as they were; `published` with a
future `publishedAt` is 422; a bulk-published scheduled article is live at once;
a category, author or tag id that does not exist is 422; a `<script>` or an
`onerror=` in the body is 422; saving an article twice without a change leaves
its `updatedAt` where it was.

**CMS pages** — every block type renders; a page removed from the header menu
disappears from the navigation; `showInFooter` moves it between footer columns,
and every page placed in a column is drawn in it. The list holds the eleven
built-in pages beside the written ones, and the home record answers at `/` (its
preview token too, `/home` redirecting there). Deleting `home`, `contact`, a
legal text or a built-in page is 409 — alone or in a bulk delete, which then
deletes nothing and names them in `data.refused`; changing their slug is 422;
unpublishing a built-in page is 422; a redirect switched on for `home` is 422.

**Header menus** — `GET /header-menus` answers the ten seeded menus in the
header's order, hidden ones left out; add a menu with two submenus, a link and a
page filed under a submenu, and find it drawn in the header with its groups; a
second "company" is 422 on `name`, and two submenus of one name 422 on
`submenus.1.name`; a `javascript:` link is 422; renaming a submenu keeps its
pages, removing one moves them to the menu's own list; an `order` PATCH
renumbers `1..n`; deleting a custom menu takes its pages out of the header and
leaves them published; deleting Buy, Rent or Commercial is 409.

**Master data** — deleting a locality a property uses is 409 and the response
names the properties; reordering by dragging renumbers the collection; a
duplicate slug is 409 and `check-slug` offers a free one. In every collection
that settles on write (testimonials, team members, partners, localities,
segments, property types, amenities, badges, developers, banks, article
categories): two records created at 0 are first in turn and one created at 3 is
third, the seeded rows follow in the order they had, the numbers read `1..n`,
and the public list reads the same way; a `PUT` of the whole first record at
`n` moves it last and answers `n` (placed by a tie it stopped one short), back at
1 moves it first again, and a `PUT` that keeps the number moves nothing. The
placing itself: a record moved down to 3 is third, one at 3 among records that
share 0 or skip numbers is third, 0 or no number is first and 99 is last
(QA-59). A name with no Latin letter or digit in it (`"!!"`, `"北京 नगर"`) is given
`<noun>-<id>` — never `''` — and a replace asking for a derived slug again keeps
it; a second "Whitefield" (or "  whitefield ") in Bengaluru is 422 on `name`,
one in another city is 201, and renaming or moving a locality into a twin is
422 while a write that keeps its own name is 200; `"  Mysuru  "` and `" Karnataka "` are stored as `Mysuru` and `Karnataka`
(and sort after Bengaluru), a locality's highlights and connectivity rows are
trimmed too, a `PATCH` is trimmed, and a badge named `" A "` is 422 on `name`;
`sort=category` on amenities reads basic, lifestyle, safety, sports, kids, eco,
convenience, commercial, and the reverse with `order=desc`; with an amenity, a
badge, a locality and a developer switched off, the public read of a listing
leaves out the amenity and the badge (its card too) and answers
`{ id, name, slug: null }` for the locality and the developer, while the admin
read keeps all four as stored (QA-60).

**FAQs** — an `order` PATCH carrying `after: <id>` lands immediately after that
record even when several records share a number, and one sent with stale numbers
still lands by the id; a FAQ created at 0 is first and at 3 is third, one saved
from 2 to 5 is fifth, and no two FAQs share an `order`; an answer with no words
(`<ul><li><p></p></li></ul>`) or with a `<script>` is 422 on `answer`;
`propertyTypeId: 99999` is 422; the same question twice in one category is 422
on `question`, and in another category is 201; `q=<p` finds nothing and
`q=R%26D` finds an answer stored as `R&amp;D`; a bulk delete naming two FAQs a
page shows is 409 with both in `data.refused[]`, and deletes nothing; a property
page lists the FAQs tied to its type after its own (QA-59).

**Content** — delete the first of three testimonials and the others read `1, 2`,
not `2, 3`; a bulk delete of two leaves the rest dense too, and the same holds for
team members and partners; an opening created with `"  Site Engineer "` and
`"Sales "` is stored as `Site Engineer` and `Sales`, and one whose description is
`<ul><li><p></p></li></ul>` or carries an `onclick` is 422 on `description` (a
`PATCH` of `isActive` alone is not asked about it); an opening whose `closesAt`
is today in IST is on `GET /jobs` until midnight IST and off it from 00:00 IST,
when `GET /jobs/slug/:slug` answers it with `isOpen: false` and
`POST /jobs/:id/apply` is 404 "This opening is closed."; `GET
/admin/job-applications?sort=status` reads new, shortlisted, interview,
rejected, hired, and the reverse with `order=desc`; with a team member switched
off, the public read of a listing that names them answers only what the listing
typed itself (`name`, `phone`, `whatsapp`, `email`, `photoUrl` `null` when it
typed nothing), while the admin read keeps them (QA-61).

**SEO** — the panel saves and the score comes back on the next read; the overview
flags two records that share a focus keyword; a redirect added in the admin
resolves; `/sitemap.xml`, `/robots.txt`, `/rss.xml` and `/llms.txt` all answer
with the right content type and absolute URLs.

**Settings** — a partial `PUT` changes one key and leaves the group alone; the
public `GET /settings` omits `leads`; a manager sees the form read-only. Open the
settings in two tabs, save the hero title in one and the tagline in the other:
both survive (QA-64).

**Users** — `aaaaaaaa` and `12345678` are refused as a new account's password and
as a reset (422 on `password`); a reset signs that account out of every session;
a bulk deactivate of an account that is already inactive reports `affected: 0`
(QA-64).

**My profile** — a 501-character `avatarUrl` is 422 on `avatarUrl` and 500 is
taken; six wrong current passwords in a minute on `PUT /auth/password` answer
422 five times and then 429, for every session of that account and for no other
account (QA-65).

**URLs** — any `url` of 501 characters is 422 under its key and 500 is taken: a
partner's `logoUrl`, a lead's `pageUrl`, an application's `resumeUrl`, a
listing's `videoUrl`, an article's `featuredImage.url`, the settings'
`general.logoUrl` and `footer.galleryImageUrls.1`, the SEO settings'
`defaults.ogImageUrl` (QA-65).

**Media** — a record whose URL a listing uses refuses to delete with 409 and its
`usedIn` list, and `?force=true` deletes it anyway. A bank's logo, an author's
photograph and the SEO settings' share image count as uses too; `meta.folders`
lists every folder on the first page, and under `type=document` only the folders
holding documents; `q` finds a file by its address and its tags; a second record
for the same address is 422 on `url`; `" /a//b/ "` is filed as the folder `a/b`;
a bulk delete with one file in use removes nothing (QA-63).

**Dashboard** — the 30-day trend has 30 entries including the empty days; the
conversion rate matches the lead counts; every figure a sales user sees is scoped.

Finish with the four commands, and keep their output with the release notes:

```bash
npm run smoke -- --baseUrl=<the API>
npm run smoke -- --baseUrl=<the API> --compare=http://localhost:4000/api
npm run check:guidelines
# and the Postman collection run, green
```
